# Pantry Relay: judge submission kit

Project lead: Shivam Gupta
Event: Hack Away Hunger 2026

Live application: https://pantryrelay.web.app
Video walkthrough and pitch: https://pantryrelay.web.app/demo
Public YouTube demo: https://www.youtube.com/watch?v=dSc6ToJ2z6Y
Submitted project: https://devpost.com/software/pantry-relay
Source code: https://github.com/shi1720/Hack-Away-Hunger

Pantry Relay helps an approved pantry network fill upcoming category gaps with
food another pantry can spare. It protects the sender's own reserve, explains
possible transfers, and records what the receiver actually accepted.

## Start here

1. Watch media/Pantry-Relay-Demo.mp4, approximately 2 minutes 51 seconds.
   Matching captions are in media/Pantry-Relay-Captions.srt.
2. Open the live application and select Explore the live demo. No shared password
   or API key is needed. Registration also creates a separate empty network.
3. Follow docs/TESTING-INSTRUCTIONS.md for the exact walkthrough and expected
   results, account and driver tests, recovery paths and automated checks.
4. Read presentation/Pantry-Relay-Pitch.pdf or Pantry-Relay-Brief.pdf for the
   problem, product and pilot. An editable PowerPoint version is included.

The central demonstration reserves and dispatches 120 pounds, accepts 112 pounds,
records an 8-pound exception and leaves the remaining need visible. The app counts
accepted pounds, not unverified meals, people fed or avoided waste.

## Evidence and plans

docs/VERIFICATION.md records completed backend, browser, deployment and media
checks with their limits. docs/BUSINESS-MODEL.md explains the proposed $149 monthly
network price and cost assumptions. docs/PILOT-PLAN.md describes a proposed
six-week supervised pilot. Pricing, willingness to pay and field impact remain
unvalidated. This is working software for a supervised pilot, not a certified
production service or a claim of nonprofit adoption.

## Demonstration and credit

All pantry names, food records and operational results shown in the demonstration
are fictional sample data. No household records are required or included.
The video uses synthetic narration, not a recording of Shivam's voice. Shivam
directed the project, priorities and quality requirements; AI tools assisted
extensively with research, implementation, testing and documentation.

The archive contains selected public presentation and evaluation materials.
Application source and its MIT license are in the linked repository. No private
credentials, account databases or internal eligibility correspondence are included.
SHA256SUMS.txt lists the contents' integrity hashes.
